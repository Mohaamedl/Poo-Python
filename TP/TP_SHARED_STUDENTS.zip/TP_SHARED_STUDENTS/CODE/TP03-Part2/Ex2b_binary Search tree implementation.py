
# from https://codereview.stackexchange.com/questions/200699/bst-implementation-in-python

#  1) initilize the binary Search tree
#  2) Implement the "put" and "contains" methods with helper function
#  3) Test the "inOrderTraversal" method.
#  4) Add additional relevant tests


import unittest

class BST(object):
    def __init__(self):
        self.root = Node()

    def put(self, value):
        ''' non recursive '''
        new_node = Node(value)

        if self.root:
            node = self.root

            while node:
                prev = node
                node = node.left if value < node.value else node.right

            if value < prev.value:
                prev.left = new_node
            else:
                prev.right = new_node

        else:
            self.root = new_node

    def put_rec(self, value):
        ''' recursive - can have Stack problems'''
        self._put(value, self.root)


    def _put(self, value, node):
        if node.value is None:
            node.value = value
        else:
            if value < node.value:
                if node.left is None:
                    node.left = Node()
                self._put(value, node.left)
            else:
                if node.right is None:
                    node.right = Node()
                self._put(value, node.right)


    def contains(self, value):
        ''' no recursive '''
        node = self._root

        while node:
            if node._value == value:
                return True
            node = node._left  if  value < node._value  else  node._right

        return False

    def contains_rec(self, value):
        return self._contains(value, self.root)

    def _contains(self, value, node):
        if node is None or node.value is None:
            return False
        else:
            if value == node.value:
                return True
            elif value < node.value:
                return self._contains(value, node.left)
            else:
                return self._contains(value, node.right)

    def in_order_traversal(self):
        acc = list()
        self._in_order_traversal(self.root, acc)
        return acc

    def _in_order_traversal(self, node, acc):
        if node is None or node.value is None:
            return
        self._in_order_traversal(node.left, acc)
        acc.append(node.value)
        self._in_order_traversal(node.right, acc)

class Node(object):
    def __init__(self, value=None, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

class TestBST(unittest.TestCase):
    def setUp(self):
        self.search_tree = BST()

    def test_bst(self):
        self.search_tree.put(3)
        self.search_tree.put(1)
        self.search_tree.put(2)
        self.search_tree.put(5)
        self.assertFalse(self.search_tree.contains(0))
        self.assertTrue(self.search_tree.contains(1))
        self.assertTrue(self.search_tree.contains(2))
        self.assertTrue(self.search_tree.contains(3))
        self.assertFalse(self.search_tree.contains(4))
        self.assertTrue(self.search_tree.contains(5))
        self.assertFalse(self.search_tree.contains(6))

        self.assertEqual(self.search_tree.in_order_traversal(), [1,2,3,5])

    def test_empty(self):
        self.assertEqual(self.search_tree.in_order_traversal(), [])

    def test_negative(self):
        self.search_tree.put(-1)
        self.search_tree.put(11)
        self.search_tree.put(-10)
        self.search_tree.put(50)
        self.assertTrue(self.search_tree.contains(-1))
        self.assertTrue(self.search_tree.contains(11))
        self.assertTrue(self.search_tree.contains(-10))
        self.assertTrue(self.search_tree.contains(50))

        self.assertEqual(self.search_tree.in_order_traversal(), [-10,-1,11,50])

    def test_dupes(self):
        self.search_tree.put(1)
        self.search_tree.put(2)
        self.search_tree.put(1)
        self.search_tree.put(2)
        self.assertTrue(self.search_tree.contains(1))
        self.assertTrue(self.search_tree.contains(2))

        self.assertEqual(self.search_tree.in_order_traversal(), [1,1,2,2])

    def test_none(self):
        self.search_tree.put(None)
        self.assertFalse(self.search_tree.contains(None))

        self.assertEqual(self.search_tree.in_order_traversal(), [])


#if __name__ == '__main__':
#    unittest.main()


tree1 = BST()
 
 
import random

for i in range(1000):
    tree1.put_rec(random.randint(0,10000))


print(tree1.in_order_traversal())

#print(tree1.contains_rec(20))

#print(tree1.contains_rec(333))

for i in range(100):
    number = random.randint(0,20000)
    if tree1.contains_rec(number):
        print(f"{number} in list")
    #else:
    #    print(f"{number} NOT in list") 