from binarytree import Node

root = Node(10)
root.left = Node(34)
root.right = Node(89)
root.left.left = Node(20)
root.left.right = Node(45)
root.right.left = Node(56)
root.right.right = Node(54)

def preorder(node):
    if node:
        # Print the value of the root node first
        print(node.val)

        # Recursively call preorder on the left subtree until we reach a leaf node.
        preorder(node.left)

        # Recursively call preorder on the right subtree until we reach a leaf node.
        preorder(node.right)

print(root)
preorder(root)

 