# from https://www.geeksforgeeks.org/binarytree-module-in-python/#:~:text=A%20binary%20tree%20is%20a%20data%20structure%20in,library%20helps%20to%20directly%20implement%20a%20binary%20tree.



from binarytree import Node
root = Node(3)
root.left = Node(6)
root.right = Node(8)
root.left.left = Node(10)
 
# Getting binary tree
print('Binary tree :', root)
 
# Getting list of nodes
print('List of nodes :', list(root))
 
# Getting inorder of nodes
print('Inorder of nodes :', root.inorder)
 
# Checking tree properties
print('Size of tree :', root.size)
print('Height of tree :', root.height)
 
# Get all properties at once
print('Properties of tree : \n', root.properties)


## -----------