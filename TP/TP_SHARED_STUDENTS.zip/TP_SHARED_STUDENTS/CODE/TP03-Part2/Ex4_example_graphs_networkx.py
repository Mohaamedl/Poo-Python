import networkx as nx
import matplotlib.pyplot as plt

g = nx.Graph()

print(g)

e = [('a', 'b', 0.3), ('b', 'c', 0.9), ('a', 'c', 0.5), ('c', 'd', 1.2)]
g.add_weighted_edges_from(e)
print(nx.dijkstra_path(g, 'a', 'd'))

# TODO: create example with cities
g1 = nx.Graph()
e = [('Aveiro', 'Porto', 76), ('Aveiro', 'Coimbra', 68) , 
     ('Lisboa', 'Coimbra', 203),('Porto', 'Lisboa', 322), 
     ('Aveiro', 'Lisboa', 260),  ('Lisboa', 'Faro', 278)]
g1.add_weighted_edges_from(e)
print(nx.dijkstra_path(g1, 'Porto', 'Faro'))
print(nx.dijkstra_path(g1, 'Porto', 'Coimbra'))

nx.draw(g1, with_labels=True)
plt.show()
input()

# graph plot example
G = nx.cubical_graph()
subax1 = plt.subplot(121)
nx.draw(G) # default spring_layout
subax2 = plt.subplot(122)
nx.draw(G, pos=nx.circular_layout(G), node_color='r', edge_color='b')

plt.show()
input()