
import matplotlib.pyplot as plt

import networkx as nx

g = nx.Graph()
e = [ ('1', '2', 2), 
      ('1', '3', 5), 
      ('2', '4', 6), 
      ('3', '5', 8),
      ('2', '5', 10),
      ('3', '4', 9),
      ('5', '6', 3),
      ('4', '6', 4)]

g.add_weighted_edges_from(e)

print(nx.dijkstra_path(g, '1', '6'))



nx.draw(g, with_labels=True)
plt.show()
input()
