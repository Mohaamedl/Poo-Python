from Trie import Trie
import time
import sys

## ler 
trie = Trie()
lista = []

MAX = 1000000
#MAX = 1000
with open("palavras.txt", encoding="UTF8") as fin:
    read = 0
    for line in fin.readlines():
        print(line.strip())
        read += 1
        
        trie.insert(line.strip())
        lista.append(line.strip())

        if read > MAX:
            break


print(f"SIZE of TRIE : {sys.getsizeof(trie)} bytes")
print(f"SIZE of LIST : {sys.getsizeof(lista)} bytes")



word = input('Início da palavra ?')

while len (word) > 0:

    t1=time.time()
    res = trie.query(word)
    t2 = time.time()
    res2 = [idx for idx in lista if idx.startswith(word)]
    t3 = time.time()


    print (res)
    print (res2)

    d1 = t2 - t1
    d2 = t3 - t2 
    print(f"Trie : {d1}")
    print(f"List : {d2}")

    if d1 > 0:
        print(f"Trie {d2/d1:.2f} times better")
    
    ## check if results are equal
    # list with res
    set1 = set([x[0] for x in res])
    set2 = set(res2)
    if set1.intersection(set2) == set1:
        print("EQUAL")
    else:
        print("NOT EQUAL") 


    word = input('Início da palavra ?')
