from binarytree import Node

root = Node(10)
root.left = Node(34)
root.right = Node(89)
root.left.left = Node(20)
root.left.right = Node(45)
root.right.left = Node(56)
root.right.right = Node(54)

def postorder(node):
    if node:
        # Recursively call postorder on the left subtree until we reach a leaf node.
        postorder(node.left)

        # Recursively call postorder on the right subtree until we reach a leaf node.
        postorder(node.right)

        # Print the value of the root node
        print(node.val)

print(root)
postorder(root)

 