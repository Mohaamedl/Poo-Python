from binarytree import Node

root = Node(3)
root.left = Node(6)
root.right = Node(8)
root.left.left = Node(10)
root.left.right = Node(11)
root.right.left = Node(12)

def inorder(node):
    if node:
        # Recursively call inorder on the left subtree until it reaches a leaf node
        inorder(node.left)

        # Once we reach a leaf, we print the data
        print(node.val)

        # Now, since the left subtree and the root has been printed, call inorder on right subtree recursively until we reach a leaf node.
        inorder(node.right)

print(root)
inorder(root)

 