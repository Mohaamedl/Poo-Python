from Trie import Trie
import time
import sys

MAX = 1000000
#MAX = 1000

def trie_from_file (filename):
    '''creates a Trie from file with words'''
    trie = Trie()
    #lista = []


    with open(filename, encoding="UTF8") as fin:
        read = 0
        for line in fin.readlines():
            #print(line.strip())
            read += 1
        
            trie.insert(line.strip())
            #lista.append(line.strip())

            if read > MAX:
                break

        return trie
 



def main():

    trie = trie_from_file("palavras.txt")
    word = input('Início da palavra ?')
    while len (word) > 0:
        t1=time.time()
        res = trie.query(word)
        t2 = time.time()
    
        #print(type(res))
        #print (res)
        for w in res:
            print(w[0])
    
        d1 = t2 - t1     
        print(f"Trie : {d1}")

        word = input('Início da palavra ?')

if __name__ == "__main__":
    main()